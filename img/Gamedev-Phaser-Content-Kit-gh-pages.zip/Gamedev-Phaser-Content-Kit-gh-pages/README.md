# Gamedev Phaser Content Kit

Welcome to the Gamedev Phaser Content Kit, also known as Mobile Games Starter Kit or HTML5 Game Development with Phaser. This Content Kit contains resources on how to **start building games with Phaser**. You can use it to learn the topic yourself or teach it to others either by giving a conference talk or running a hands-on workshop.

Visit the project's page at [end3r.github.io/Gamedev-Phaser-Content-Kit/](http://end3r.github.io/Gamedev-Phaser-Content-Kit/) for the detailed info and the list of avilable resources.